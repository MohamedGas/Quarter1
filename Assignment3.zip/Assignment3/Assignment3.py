#this program will display list of students with firstname , lastname, grade of the student from 
#-> file in a directory using of the name of the file 

def main():
    
    #this a display message 
    print('<:-Welcome this program will display list of students name and their grade from a file :->','\n')
    #requirements 
    print('!!-<>- It Requires To Know The Name of The File With Extension .dat -<>-!!','\n')
    ######## READING DATA ################
    #prompt user from the file name
    filename=input('Please Enter Name Of The File With Thr Extension Of The File-: ')
    #Opening The File with the mode
    input_file=open(filename,'r')
    #open another score file
    score_file_name='score.dat'
    score_file=open(score_file_name,'r')
    #reading the file from the data
    data= input_file.read()
    score_data=score_file.read()
    #close the files
    input_file.close()
    score_file.close()
    #seperate upper lines and lower lines
    print(end='\n')
    #Grades and what they based on 
    print(score_data,'\n')
    #report to the user
    print(f'First Name  |  Last Name |\t Scores ''\n',data)
    #########################################################

    ########### WRITING DATA #############################

    print('\n')
    #opening grade.dat file to able write a data of the students    
    grade_fname='grade.dat' 
    outfile_grade=open(grade_fname,'w+')
    #Creating an empty accumalate variable to hold new data
    grade=''
    #telling user what to do 
    print("Now You're Entering The New Data Of The Students : ")
    print("First Name | Last Name | Score | Grade")
    for wr in range(4):
        #Prompt The Data From The User
        x=input()
        #Accumalting the data into grade field
        grade+=x+'\n'
    #Writing the data on the file
    grade_write=outfile_grade.writelines(grade)      
    #Closing the file
    outfile_grade.close()
    #report to The User 
    print("Successfully Saved Data")

 
main()

